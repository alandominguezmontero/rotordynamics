


h=findobj('type','uicontrol');
set(h,'visible','off')
set(gca,'pos',[0 0 1 1])
ht=get(gca,'title');
set(ht,'string','')
set(gcf,'menu','figure')
