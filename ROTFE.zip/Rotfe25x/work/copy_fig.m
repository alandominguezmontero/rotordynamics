h=findobj('type','uicontrol')
set(gcf,'menu','figure')
set(h,'visible','off')

