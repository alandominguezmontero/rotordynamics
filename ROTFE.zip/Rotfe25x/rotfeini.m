%rotfeini
%
%
% adds rotfe directories to the matlab path
%

rotfe_path=pwd;
addpath([rotfe_path '/new'])
addpath([rotfe_path '/models'])
addpath([rotfe_path '/try'])
addpath([rotfe_path '/work'])