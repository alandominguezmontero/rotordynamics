% demonstrate building a rotor model (as a Matlab structure)
% and plotting it in (fancy) 3d plot
%
% By: 	Izhak Bucher
% Date:	8-June-2000
% How: 	Free for any non-profit use (no commercial use allowed)
%      As the author of this software I specifically object to
%      commerial bodies distributing this software from their  
%      WEB and forcing users to register.
% Where: mebucher@tx.technion.ac.il


 This set of matlab functions and scripts 
 computes and plots torsional vibration of shafts.

 The shaft is drawn in 3d so it takes much time for complicated
  systems ... be patient.

  demonstrations (just type the name of the script in Matlab):

    tst_rotdraw
    
     tst_rotany
