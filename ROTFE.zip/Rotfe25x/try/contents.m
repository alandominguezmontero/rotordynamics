%contents.m
%
% test the convergence of the timoshenko element
% scripts to run:
% testanax.m
% testanax2.m
%
% all other m-files are utility functions