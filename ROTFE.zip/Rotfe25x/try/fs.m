function y=fs(x)
global L A Gs E Iy rho

y=abs(dettimo(x,L,A,Gs,E,Iy,rho));