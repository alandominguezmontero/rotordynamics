% temporary file 
 % description of a Rot structure 
% Due to large size data stored in tempmat.mat 
 
 load tempmat.mat 

 % end 
